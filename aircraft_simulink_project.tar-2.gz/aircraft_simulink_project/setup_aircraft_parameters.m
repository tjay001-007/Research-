%% Aircraft Parameters Setup Script
% Sets up parameters for pitch-unstable aircraft simulation
% Run this before starting the Simulink model

clear all;
close all;
clc;

disp('========================================');
disp('Aircraft Parameters Setup');
disp('PITCH UNSTABLE Configuration');
disp('========================================');
disp(' ');

%% UDP Configuration
SIMULINK_RECEIVE_PORT = 15001;  % Receive controls from Gazebo
SIMULINK_SEND_PORT = 15000;     % Send state to Gazebo
GAZEBO_IP = '127.0.0.1';

disp('UDP Configuration:');
disp(['  Receive Port: ' num2str(SIMULINK_RECEIVE_PORT)]);
disp(['  Send Port: ' num2str(SIMULINK_SEND_PORT)]);
disp(['  Gazebo IP: ' GAZEBO_IP]);
disp(' ');

%% Aircraft Physical Parameters

aircraft.mass = 2.0;  % Mass (kg)

% Moments of inertia (kg*m^2)
aircraft.Ixx = 0.05;   % Roll axis
aircraft.Iyy = 0.1;    % Pitch axis
aircraft.Izz = 0.12;   % Yaw axis

% Geometry
aircraft.S = 0.3;      % Wing area (m^2)
aircraft.c = 0.3;      % Mean aerodynamic chord (m)
aircraft.b = 1.0;      % Wing span (m)

disp('Aircraft Mass Properties:');
disp(['  Mass: ' num2str(aircraft.mass) ' kg']);
disp(['  Ixx: ' num2str(aircraft.Ixx) ' kg*m^2']);
disp(['  Iyy: ' num2str(aircraft.Iyy) ' kg*m^2']);
disp(['  Izz: ' num2str(aircraft.Izz) ' kg*m^2']);
disp(' ');

%% Aerodynamic Coefficients

% Lift
aircraft.CL0 = 0.3;        % Base lift coefficient
aircraft.CLalpha = 4.5;    % Lift curve slope (per radian)
aircraft.CLde = 0.5;       % Elevator effectiveness on lift

% Drag
aircraft.CD0 = 0.05;       % Parasitic drag
aircraft.CDalpha = 0.1;    % Induced drag factor

% Side force
aircraft.CYbeta = -0.5;    % Sideslip to side force
aircraft.CYdr = 0.2;       % Rudder to side force

% Roll moments
aircraft.Clbeta = -0.1;    % Dihedral effect
aircraft.Clp = -0.5;       % Roll damping
aircraft.Clr = 0.1;        % Roll due to yaw rate
aircraft.Clda = 0.3;       % Aileron effectiveness

% Pitch moments (UNSTABLE CONFIGURATION!)
aircraft.Cm0 = 0.05;       % Positive = nose-up pitching moment
aircraft.Cmalpha = 0.3;    % POSITIVE = UNSTABLE! (normal aircraft is negative)
aircraft.Cmq = -3.0;       % Pitch damping (negative is good)
aircraft.Cmde = -0.8;      % Elevator effectiveness

% Yaw moments
aircraft.Cnbeta = 0.1;     % Weathercock stability
aircraft.Cnr = -0.1;       % Yaw damping
aircraft.Cnda = -0.05;     % Adverse yaw
aircraft.Cndr = -0.1;      % Rudder effectiveness

disp('Aerodynamic Coefficients:');
disp('  PITCH CHARACTERISTICS (UNSTABLE!):');
disp(['    Cm0 = ' num2str(aircraft.Cm0) ' (positive = unstable)']);
disp(['    Cmalpha = ' num2str(aircraft.Cmalpha) ' (positive = unstable)']);
disp(['    Cmq = ' num2str(aircraft.Cmq) ' (pitch damping)']);
disp(['    Cmde = ' num2str(aircraft.Cmde) ' (control authority)']);
disp(' ');
disp('  For comparison, a STABLE aircraft would have:');
disp('    Cm0 ≈ 0 (trimmed)');
disp('    Cmalpha < 0 (negative)');
disp(' ');

%% Initial Conditions

% Position (NED frame)
initial.position = [
    0;      % North (m)
    0;      % East (m)
    -100    % Down (m) - negative = 100m altitude
];

% Euler angles (radians)
initial.euler = [
    0;      % Roll (phi)
    0.1;    % Pitch (theta) - slight nose-up
    0       % Yaw (psi)
];

% Velocity (body frame, m/s)
initial.velocity_body = [
    20;     % u - forward velocity
    0;      % v - lateral velocity
    0       % w - vertical velocity
];

% Angular rates (body frame, rad/s)
initial.omega_body = [
    0;      % p - roll rate
    0;      % q - pitch rate
    0       % r - yaw rate
];

% State vector: [u v w p q r x y z phi theta psi]
initial.state = [
    initial.velocity_body;
    initial.omega_body;
    initial.position;
    initial.euler
];

disp('Initial Conditions:');
disp(['  Altitude: ' num2str(-initial.position(3)) ' m']);
disp(['  Airspeed: ' num2str(norm(initial.velocity_body)) ' m/s']);
disp(['  Pitch: ' num2str(rad2deg(initial.euler(2))) ' deg']);
disp(' ');

%% Simulation Parameters

dt = 0.004;         % Time step (250 Hz)
sim_time = 300;     % Simulation time (seconds)

disp('Simulation Parameters:');
disp(['  Time Step: ' num2str(dt) ' s (' num2str(1/dt) ' Hz)']);
disp(['  Simulation Time: ' num2str(sim_time) ' s']);
disp(' ');

%% Save to MAT file

save('aircraft_params.mat', 'aircraft', 'initial', 'dt', 'sim_time', ...
     'SIMULINK_RECEIVE_PORT', 'SIMULINK_SEND_PORT', 'GAZEBO_IP');

disp('✓ Parameters saved to: aircraft_params.mat');
disp(' ');

%% Display Flight Characteristics

disp('========================================');
disp('Flight Characteristics Analysis');
disp('========================================');

% Calculate static margin (negative = unstable)
x_cg = 0.5;  % CG at 50% MAC (assumed)
x_ac = x_cg - aircraft.Cmalpha / aircraft.CLalpha;
static_margin = (x_ac - x_cg) / aircraft.c;

disp(['Static Margin: ' num2str(static_margin*100) '% MAC']);
if static_margin < 0
    disp('  ⚠ NEGATIVE - Aircraft is STATICALLY UNSTABLE in pitch!');
    disp('  → Active control is REQUIRED for stable flight');
else
    disp('  ✓ Positive - Aircraft is statically stable');
end
disp(' ');

% Calculate natural frequency and damping
V_cruise = 20;  % m/s
q_cruise = 0.5 * 1.225 * V_cruise^2;
omega_n = sqrt(q_cruise * aircraft.S * aircraft.c * abs(aircraft.Cmalpha) / ...
               (aircraft.Iyy * V_cruise));
zeta = -aircraft.Cmq * q_cruise * aircraft.S * aircraft.c^2 / ...
        (2 * aircraft.Iyy * V_cruise * omega_n);

disp('Short Period Mode (approximation):');
disp(['  Natural Frequency: ' num2str(omega_n) ' rad/s']);
disp(['  Damping Ratio: ' num2str(zeta)]);
if zeta < 0
    disp('  ⚠ NEGATIVE DAMPING - Divergent oscillations!');
elseif zeta < 0.3
    disp('  ⚠ Low damping - Oscillatory response');
else
    disp('  ✓ Adequate damping');
end
disp(' ');

%% Control Recommendations

disp('========================================');
disp('PX4 Control Recommendations');
disp('========================================');
disp('For this pitch-unstable aircraft, you should:');
disp(' ');
disp('1. INCREASE pitch control gains significantly:');
disp('   MC_PITCH_P: Start with 10-15 (default ~6)');
disp('   MC_PITCHRATE_P: Start with 0.3-0.5 (default ~0.15)');
disp('   MC_PITCHRATE_D: Start with 0.01-0.02 (default ~0.003)');
disp(' ');
disp('2. INCREASE control loop rate if possible');
disp('   - Faster loop = better handling of instability');
disp(' ');
disp('3. Consider FEEDFORWARD control:');
disp('   - Add alpha feedforward term');
disp('   - Helps compensate for Cmalpha > 0');
disp(' ');
disp('4. TEST in simulation first!');
disp('   - Use PX4 SITL with this model');
disp('   - Tune gains before flight');
disp(' ');

disp('========================================');
disp('Setup Complete!');
disp('========================================');
disp(' ');
disp('Next steps:');
disp('1. Start Gazebo: gazebo aircraft_world.world');
disp('2. Run: build_simulink_model (if not done)');
disp('3. Open: open_system(''aircraft_udp_sim'')');
disp('4. Start simulation');
disp(' ');
