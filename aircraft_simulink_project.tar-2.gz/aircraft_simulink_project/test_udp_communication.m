%% Test UDP Communication
% This script tests UDP communication before running the full simulation
% Tests both sending and receiving functionality

clear all;
close all;
clc;

disp('========================================');
disp('UDP Communication Test');
disp('========================================');
disp(' ');

%% Load parameters
if exist('aircraft_params.mat', 'file')
    load('aircraft_params.mat', 'SIMULINK_RECEIVE_PORT', 'SIMULINK_SEND_PORT', 'GAZEBO_IP');
    disp('✓ Loaded UDP configuration from aircraft_params.mat');
else
    % Use defaults
    SIMULINK_RECEIVE_PORT = 15001;
    SIMULINK_SEND_PORT = 15000;
    GAZEBO_IP = '127.0.0.1';
    disp('⚠ Using default UDP configuration');
end

disp(['  Receive Port: ' num2str(SIMULINK_RECEIVE_PORT)]);
disp(['  Send Port: ' num2str(SIMULINK_SEND_PORT)]);
disp(['  Target IP: ' GAZEBO_IP]);
disp(' ');

%% Test 1: Check if ports are available

disp('Test 1: Checking port availability...');

try
    % Try to open receive port
    test_receive = udpport("datagram", "LocalPort", SIMULINK_RECEIVE_PORT, "Timeout", 0.1);
    disp(['  ✓ Port ' num2str(SIMULINK_RECEIVE_PORT) ' is available']);
    clear test_receive;
catch ME
    disp(['  ✗ Port ' num2str(SIMULINK_RECEIVE_PORT) ' is in use or unavailable']);
    disp(['    Error: ' ME.message]);
    return;
end

try
    % Try to create send socket
    test_send = udpport("datagram");
    disp('  ✓ Can create UDP send socket');
    clear test_send;
catch ME
    disp('  ✗ Cannot create UDP send socket');
    disp(['    Error: ' ME.message]);
    return;
end

disp(' ');

%% Test 2: Send test state packet

disp('Test 2: Sending test state packet...');

try
    % Create send socket
    udp_send = udpport("datagram");
    
    % Create test state packet (64 bytes)
    test_position = single([10.0; 20.0; -50.0]);  % x, y, z
    test_quaternion = single([1.0; 0.0; 0.0; 0.0]);  % w, x, y, z
    test_velocity = single([15.0; 0.0; 0.0]);  % u, v, w
    test_omega = single([0.1; 0.2; 0.05]);  % p, q, r
    test_accel = single([0.0; 0.0; -9.81]);  % ax, ay, az
    
    % Pack into single array
    state_vector = [test_position; test_quaternion; test_velocity; test_omega; test_accel];
    packet_data = typecast(state_vector, 'uint8');
    
    % Send packet
    write(udp_send, packet_data, "uint8", GAZEBO_IP, SIMULINK_SEND_PORT);
    
    disp(['  ✓ Sent ' num2str(length(packet_data)) ' bytes to ' GAZEBO_IP ':' num2str(SIMULINK_SEND_PORT)]);
    disp('    Test state: Position=[10, 20, -50], Velocity=[15, 0, 0]');
    
    clear udp_send;
catch ME
    disp('  ✗ Failed to send packet');
    disp(['    Error: ' ME.message]);
end

disp(' ');

%% Test 3: Listen for incoming control packets

disp('Test 3: Listening for control packets (5 second timeout)...');
disp('  If Gazebo is running, you should see control data');
disp('  If not, this will timeout (normal for standalone test)');
disp(' ');

try
    % Create receive socket
    udp_receive = udpport("datagram", "LocalPort", SIMULINK_RECEIVE_PORT, "Timeout", 5);
    
    packets_received = 0;
    start_time = tic;
    
    while toc(start_time) < 5
        if udp_receive.NumDatagramsAvailable > 0
            data = read(udp_receive, 1, "uint8");
            
            if length(data.Data) >= 20
                % Unpack control packet
                aileron = typecast(uint8(data.Data(1:4)), 'single');
                elevator = typecast(uint8(data.Data(5:8)), 'single');
                rudder = typecast(uint8(data.Data(9:12)), 'single');
                throttle = typecast(uint8(data.Data(13:16)), 'single');
                
                packets_received = packets_received + 1;
                
                if packets_received == 1
                    disp('  ✓ Received control packet!');
                end
                
                fprintf('    Aileron: %+.3f, Elevator: %+.3f, Rudder: %+.3f, Throttle: %.3f\n', ...
                        aileron, elevator, rudder, throttle);
            end
        end
        pause(0.1);
    end
    
    if packets_received > 0
        disp(' ');
        disp(['  ✓ Total packets received: ' num2str(packets_received)]);
    else
        disp(' ');
        disp('  ⚠ No packets received (Gazebo may not be running)');
        disp('    This is NORMAL if testing without Gazebo');
    end
    
    clear udp_receive;
catch ME
    disp('  ✗ Failed to listen for packets');
    disp(['    Error: ' ME.message]);
end

disp(' ');

%% Test 4: Loopback test

disp('Test 4: Loopback test (send and receive)...');

try
    % Create both sockets
    udp_receive = udpport("datagram", "LocalPort", 15555, "Timeout", 1);
    udp_send = udpport("datagram");
    
    % Send test packet to ourselves
    test_data = uint8([1, 2, 3, 4, 5]);
    write(udp_send, test_data, "uint8", "127.0.0.1", 15555);
    
    pause(0.1);
    
    if udp_receive.NumDatagramsAvailable > 0
        received = read(udp_receive, 1, "uint8");
        
        if isequal(test_data, received.Data')
            disp('  ✓ Loopback test PASSED');
            disp('    UDP stack is working correctly');
        else
            disp('  ✗ Loopback test FAILED - data mismatch');
        end
    else
        disp('  ✗ Loopback test FAILED - no data received');
        disp('    Check firewall settings');
    end
    
    clear udp_receive udp_send;
catch ME
    disp('  ✗ Loopback test failed');
    disp(['    Error: ' ME.message]);
end

disp(' ');

%% Summary

disp('========================================');
disp('Test Summary');
disp('========================================');
disp(' ');
disp('If all tests passed:');
disp('  → UDP communication is working');
disp('  → Ready to run simulation');
disp(' ');
disp('If Test 3 timed out but others passed:');
disp('  → Normal without Gazebo running');
disp('  → Start Gazebo before running simulation');
disp(' ');
disp('If tests failed:');
disp('  1. Check firewall settings');
disp('  2. Make sure ports are not in use');
disp('  3. Try different port numbers');
disp('  4. Run MATLAB as administrator (if needed)');
disp(' ');

disp('Next step: Run build_simulink_model.m');
disp(' ');
