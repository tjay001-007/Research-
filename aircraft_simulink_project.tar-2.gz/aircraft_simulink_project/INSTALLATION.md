# COMPLETE INSTALLATION GUIDE
# Simulink UDP Aircraft Simulation for PX4

## 📦 What You'll Build

A complete simulation system with:
- ✈️ Pitch-unstable aircraft dynamics in Simulink
- 🔌 UDP communication (no ROS Toolbox required!)
- 🎮 Gazebo visualization
- 🤖 PX4 integration ready

---

## 🎯 Quick Start (5 Steps)

### Step 1: Setup MATLAB Files

```matlab
% In MATLAB, navigate to project directory
cd /path/to/aircraft_simulink_project

% Run setup (creates aircraft_params.mat)
setup_aircraft_parameters
```

**✓ You should see:** Aircraft parameters with Cm0 > 0 (unstable!)

### Step 2: Build Simulink Model

```matlab
% Creates aircraft_udp_sim.slx
build_simulink_model
```

**✓ You should see:** Simulink model opens automatically with UDP blocks

### Step 3: Test UDP (Optional but Recommended)

```matlab
% Test communication before full simulation
test_udp_communication
```

**✓ You should see:** All tests pass (Test 3 may timeout without Gazebo - that's OK)

### Step 4: Start Gazebo

Open a terminal:
```bash
cd ~/gazebo_udp_bridge
export GAZEBO_MODEL_PATH=$GAZEBO_MODEL_PATH:~/gazebo_udp_bridge/models
export GAZEBO_PLUGIN_PATH=$GAZEBO_PLUGIN_PATH:~/.gazebo/plugins
gazebo worlds/aircraft_world.world --verbose
```

**✓ You should see in console:**
```
UDP Bridge initialized:
  Receiving state on port: 15000
  Sending controls to: 127.0.0.1:15001
```

### Step 5: Run Simulation

Back in MATLAB:
```matlab
% Launches everything automatically
run_simulation
```

**✓ You should see:** 
- Simulink model running
- Aircraft appears in Gazebo
- Aircraft responding to (zero) controls

---

## 🔧 Detailed Installation

### Prerequisites

**MATLAB:**
- Version: R2020b or later
- Required: Base Simulink only
- Optional: Aerospace Blockset (for templates)
- **NOT required:** ROS Toolbox, Instrument Control Toolbox

**System:**
- Ubuntu 20.04 or later
- Gazebo 11
- 4+ GB RAM
- Python 3 (for PX4, optional)

### Install Gazebo Plugin (From Earlier Instructions)

```bash
# Build UDP plugin
cd ~/gazebo_udp_bridge/build
cmake ..
make
sudo make install

# Or local install
mkdir -p ~/.gazebo/plugins
cp libudp_dynamics_plugin.so ~/.gazebo/plugins/
```

---

## 📝 File Structure After Installation

```
aircraft_simulink_project/
├── aircraft_udp_sim.slx              ← Main Simulink model
├── aircraft_params.mat                ← Generated parameters
│
├── build_simulink_model.m             ← Model builder
├── setup_aircraft_parameters.m        ← Parameter setup
│
├── aircraft_6dof_sfunc.m              ← Dynamics S-function
├── udp_receive_sfunc.m                ← UDP receive
├── udp_send_sfunc.m                   ← UDP send
│
├── run_simulation.m                   ← Main launcher
├── test_udp_communication.m           ← UDP tester
├── manual_control_test.m              ← Manual controls
│
└── README.md                          ← Full documentation
```

---

## 🎮 Usage Examples

### Example 1: Basic Flight

```matlab
% 1. Setup
setup_aircraft_parameters
build_simulink_model

% 2. Start Gazebo (in terminal)
% gazebo worlds/aircraft_world.world

% 3. Run
run_simulation
```

### Example 2: Custom Initial Conditions

```matlab
% Edit initial conditions
initial.position = [0; 0; -200];        % 200m altitude
initial.velocity_body = [25; 0; 0];     % 25 m/s forward
initial.euler = [0; deg2rad(5); 0];     % 5 deg pitch up

% Save
save('aircraft_params.mat', 'aircraft', 'initial', '-append');

% Run
run_simulation
```

### Example 3: Manual Control Testing

```matlab
% Send specific control inputs
manual_control_test

% Select option 2 for pitch up test
% Select option 7 for interactive sliders
```

### Example 4: Different Aircraft Configuration

```matlab
% Make aircraft MORE unstable
aircraft.Cm0 = 0.1;        % Increase from 0.05
aircraft.Cmalpha = 0.5;    % Increase from 0.3

% Or make it stable
aircraft.Cm0 = 0;          % Neutral
aircraft.Cmalpha = -0.3;   % Negative = stable

% Save and run
save('aircraft_params.mat', 'aircraft', '-append');
run_simulation
```

---

## 🐛 Troubleshooting

### Problem: "Undefined function 'udpport'"

**Cause:** MATLAB version too old

**Solution 1 - Update MATLAB:**
```matlab
ver  % Check version - need R2020b+
```

**Solution 2 - Use Legacy UDP:**
Replace in S-functions:
```matlab
% Old way (legacy)
udp_obj = udp('127.0.0.1', 15000, 'LocalPort', 15001);
fopen(udp_obj);
% ... use fwrite/fread instead of write/read
```

### Problem: "Port already in use"

**Solution:**
```matlab
% Clear all UDP objects
instrfindall
delete(instrfindall)

% Or restart MATLAB
```

### Problem: "S-Function not found"

**Solution:**
```matlab
% Make sure on path
addpath(genpath(pwd));
rehash toolboxcache;

% Check files exist
exist('aircraft_6dof_sfunc.m', 'file')
```

### Problem: Gazebo doesn't show aircraft

**Check:**
1. Is plugin loaded? `gz model -m pitch_unstable_aircraft -i`
2. Is UDP receiving? Check Gazebo console for packet count
3. Is Simulink sending? Check "UDP Send" display in model

**Solutions:**
```bash
# Restart Gazebo with verbose
gazebo --verbose

# Check UDP traffic
netstat -an | grep 15000
```

### Problem: Aircraft diverges immediately

**This is NORMAL!** - The aircraft is pitch unstable.

**Solutions:**
1. Add control inputs (use manual_control_test.m)
2. Integrate with PX4 for automatic stabilization
3. Reduce Cm0 and Cmalpha for testing

---

## 🔬 Advanced: Connecting to PX4

### PX4 SITL Setup

```bash
# Start PX4 SITL (separate terminal)
cd ~/PX4-Autopilot
make px4_sitl none_iris

# In another terminal, start MAVROS
roslaunch mavros px4.launch fcu_url:="udp://:14540@127.0.0.1:14557"
```

### Modify Gazebo Plugin for PX4

Add to `udp_dynamics_plugin.cpp`:
```cpp
#include <ros/ros.h>
#include <mavros_msgs/ActuatorControl.h>

// In Load():
mavros_sub = nh.subscribe("/mavros/actuator_control", 10,
    &UDPDynamicsPlugin::actuatorCallback, this);

// Add callback:
void actuatorCallback(const mavros_msgs::ActuatorControl::ConstPtr& msg) {
    controlPacket.aileron = msg->controls[0];
    controlPacket.elevator = msg->controls[1];
    controlPacket.rudder = msg->controls[2];
    controlPacket.throttle = msg->controls[3];
}
```

Recompile and launch!

---

## 📊 Performance Tuning

### For Real-Time Performance:

```matlab
% Reduce visual overhead
set_param('aircraft_udp_sim', 'EnablePacing', 'off');

% Close unnecessary scopes
% (Comment out scope connections in build script)

% Use Accelerator mode (if available)
set_param('aircraft_udp_sim', 'SimulationMode', 'accelerator');
```

### For Accuracy:

```matlab
% Use higher-order solver
set_param('aircraft_udp_sim', 'Solver', 'ode45');

% Smaller time step
dt = 0.002;  % 500 Hz instead of 250 Hz
```

---

## 📚 Next Steps

1. **Tune PX4 Parameters:** See README.md for recommended gains
2. **Add Sensors:** Modify S-function to add GPS, IMU noise
3. **Test Maneuvers:** Use manual_control_test.m
4. **Log Data:** Add To Workspace blocks in Simulink
5. **Visualization:** Use MATLAB plotting for analysis

---

## ✅ Verification Checklist

After installation, verify:

- [ ] `aircraft_params.mat` exists
- [ ] `aircraft_udp_sim.slx` opens without errors
- [ ] UDP test passes (tests 1, 2, 4)
- [ ] Gazebo shows aircraft model
- [ ] Gazebo console shows "UDP Bridge initialized"
- [ ] Simulation runs for >10 seconds
- [ ] Aircraft moves in Gazebo
- [ ] Scopes show changing data

---

## 🆘 Getting Help

**Check logs:**
```matlab
% MATLAB warnings
lastwarn

% Simulink diagnostics
sldiagviewer
```

**Gazebo logs:**
```bash
# Check Gazebo console output
# Look for "UDP" messages

# Verbose mode
gazebo --verbose
```

**Common solutions:**
1. Restart MATLAB
2. Restart Gazebo
3. Clear UDP objects: `instrfindall; delete(instrfindall)`
4. Rebuild model: `build_simulink_model`
5. Reset parameters: `setup_aircraft_parameters`

---

## 🎓 Learning Resources

**Understand the Math:**
- Stevens & Lewis: "Aircraft Control and Simulation"
- See equations in `aircraft_6dof_sfunc.m`

**Improve Control:**
- PX4 docs: https://docs.px4.io
- Tune pitch gains for unstable aircraft

**Extend the Model:**
- Add wind gusts
- Add sensor noise
- Implement different aircraft

---

## ✨ You're Ready!

Run this to get started:
```matlab
setup_aircraft_parameters
build_simulink_model  
test_udp_communication
run_simulation
```

Good luck with your pitch-unstable aircraft control!
