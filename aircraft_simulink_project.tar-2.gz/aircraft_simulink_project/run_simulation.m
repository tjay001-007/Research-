%% Run Aircraft Simulation
% Main script to run the complete UDP-based aircraft simulation
% This script handles setup, model loading, and simulation execution

clear all;
close all;
clc;

disp('================================================');
disp('Aircraft UDP Simulation - Main Launcher');
disp('Pitch Unstable Aircraft + Gazebo Integration');
disp('================================================');
disp(' ');

%% Step 1: Check prerequisites

disp('Step 1: Checking prerequisites...');

% Check if model exists
if ~exist('aircraft_udp_sim.slx', 'file')
    disp('  ✗ Simulink model not found');
    disp(' ');
    disp('Building model now...');
    try
        build_simulink_model;
        disp('  ✓ Model created successfully');
    catch ME
        error('Failed to build model: %s', ME.message);
    end
else
    disp('  ✓ Simulink model found');
end

% Check if parameters are loaded
if ~exist('aircraft_params.mat', 'file')
    disp('  ⚠ Parameters file not found');
    disp(' ');
    disp('Running setup...');
    try
        setup_aircraft_parameters;
        disp('  ✓ Parameters created successfully');
    catch ME
        error('Failed to setup parameters: %s', ME.message);
    end
else
    disp('  ✓ Parameters file found');
    load('aircraft_params.mat');
    disp(['    - Receive Port: ' num2str(SIMULINK_RECEIVE_PORT)]);
    disp(['    - Send Port: ' num2str(SIMULINK_SEND_PORT)]);
end

% Check all S-functions exist
required_files = {'aircraft_6dof_sfunc.m', 'udp_receive_sfunc.m', 'udp_send_sfunc.m'};
all_found = true;
for i = 1:length(required_files)
    if ~exist(required_files{i}, 'file')
        disp(['  ✗ Missing: ' required_files{i}]);
        all_found = false;
    end
end

if all_found
    disp('  ✓ All S-functions found');
else
    error('Missing required files. Check installation.');
end

disp(' ');

%% Step 2: Pre-flight checks

disp('Step 2: Pre-flight checks...');

% Check UDP ports
disp('  Checking UDP ports...');
try
    temp_udp = udpport("datagram", "LocalPort", SIMULINK_RECEIVE_PORT, "Timeout", 0.1);
    clear temp_udp;
    disp(['    ✓ Port ' num2str(SIMULINK_RECEIVE_PORT) ' available']);
catch
    warning(['Port ' num2str(SIMULINK_RECEIVE_PORT) ' may be in use. Clearing...']);
    try
        instrfindall;
        delete(instrfindall);
        pause(0.5);
    catch
    end
end

% Check if Gazebo might be running
disp('  Checking for Gazebo connection...');
udp_test = udpport("datagram");
test_packet = uint8(zeros(64,1));
try
    write(udp_test, test_packet, "uint8", GAZEBO_IP, SIMULINK_SEND_PORT);
    disp('    ✓ Can send to Gazebo port');
    disp('    ℹ If Gazebo is running, it should receive this test packet');
catch ME
    disp(['    ⚠ Cannot send to Gazebo: ' ME.message]);
end
clear udp_test;

disp(' ');

%% Step 3: Load and configure model

disp('Step 3: Loading Simulink model...');

model_name = 'aircraft_udp_sim';

% Close if already open
if bdIsLoaded(model_name)
    disp('  Model already loaded, closing...');
    close_system(model_name, 0);
end

% Load model
try
    load_system(model_name);
    disp('  ✓ Model loaded successfully');
catch ME
    error('Failed to load model: %s', ME.message);
end

% Configure model parameters
disp('  Configuring simulation parameters...');
set_param(model_name, 'Solver', 'ode4');
set_param(model_name, 'FixedStep', num2str(dt));
set_param(model_name, 'StopTime', 'inf');
set_param(model_name, 'SaveFormat', 'Array');

disp(['    - Solver: Fixed-step ODE4']);
disp(['    - Step size: ' num2str(dt) ' s (' num2str(1/dt) ' Hz)']);
disp(['    - Stop time: Infinite (manual stop)']);

disp(' ');

%% Step 4: Display flight information

disp('================================================');
disp('Aircraft Configuration');
disp('================================================');
disp(' ');
disp('Mass Properties:');
disp(['  Mass: ' num2str(aircraft.mass) ' kg']);
disp(['  Inertia: Ixx=' num2str(aircraft.Ixx) ', Iyy=' num2str(aircraft.Iyy) ', Izz=' num2str(aircraft.Izz)]);
disp(' ');
disp('Pitch Stability (CRITICAL):');
disp(['  Cm0 = ' num2str(aircraft.Cm0) ' (positive = unstable!)']);
disp(['  Cmalpha = ' num2str(aircraft.Cmalpha) ' (positive = unstable!)']);
disp(['  Cmq = ' num2str(aircraft.Cmq) ' (pitch damping)']);
disp(' ');
disp('Initial Conditions:');
disp(['  Altitude: ' num2str(-initial.position(3)) ' m']);
disp(['  Airspeed: ' num2str(norm(initial.velocity_body)) ' m/s']);
disp(['  Pitch: ' num2str(rad2deg(initial.euler(2))) ' deg']);
disp(' ');

%% Step 5: Instructions for Gazebo

disp('================================================');
disp('IMPORTANT: Gazebo Setup');
disp('================================================');
disp(' ');
disp('Before starting simulation, make sure Gazebo is running:');
disp(' ');
disp('In a terminal:');
disp('  cd ~/gazebo_udp_bridge');
disp('  export GAZEBO_MODEL_PATH=$GAZEBO_MODEL_PATH:~/gazebo_udp_bridge/models');
disp('  export GAZEBO_PLUGIN_PATH=$GAZEBO_PLUGIN_PATH:~/.gazebo/plugins');
disp('  gazebo worlds/aircraft_world.world --verbose');
disp(' ');
disp('You should see:');
disp('  "UDP Bridge initialized"');
disp('  "Receiving state on port: 15000"');
disp('  "Sending controls to: 127.0.0.1:15001"');
disp(' ');

%% Step 6: Ask user to confirm

disp('================================================');
reply = input('Is Gazebo running and ready? (y/n): ', 's');

if ~strcmpi(reply, 'y')
    disp(' ');
    disp('⚠ Start Gazebo first, then run this script again.');
    disp(' ');
    disp('Keeping model loaded for manual start.');
    disp('When ready, run: set_param(''aircraft_udp_sim'', ''SimulationCommand'', ''start'')');
    open_system(model_name);
    return;
end

disp(' ');

%% Step 7: Open model and start simulation

disp('================================================');
disp('Starting Simulation');
disp('================================================');
disp(' ');

% Open model UI
open_system(model_name);
disp('✓ Model UI opened');

% Wait a moment for everything to initialize
pause(1);

% Start simulation
disp(' ');
disp('Starting simulation in 3 seconds...');
disp('Watch Gazebo for aircraft movement!');
disp(' ');
pause(1);
disp('3...');
pause(1);
disp('2...');
pause(1);
disp('1...');
pause(1);

try
    set_param(model_name, 'SimulationCommand', 'start');
    disp(' ');
    disp('✓✓✓ SIMULATION RUNNING ✓✓✓');
    disp(' ');
    disp('================================================');
    disp('Monitoring');
    disp('================================================');
    disp(' ');
    disp('Monitor in:');
    disp('  • Simulink scopes (Position, Attitude, Controls)');
    disp('  • Gazebo visualization');
    disp('  • MATLAB Command Window (UDP status)');
    disp(' ');
    disp('To stop:');
    disp('  set_param(''aircraft_udp_sim'', ''SimulationCommand'', ''stop'')');
    disp('  or press Stop button in Simulink');
    disp(' ');
    
    % Monitor simulation
    disp('Simulation status updates:');
    for i = 1:30  % Monitor for 30 seconds
        status = get_param(model_name, 'SimulationStatus');
        time = get_param(model_name, 'SimulationTime');
        
        if strcmp(status, 'stopped')
            disp(' ');
            disp('⚠ Simulation stopped');
            break;
        end
        
        if mod(i, 5) == 0
            fprintf('  Time: %.1f s - Status: %s\n', str2double(time), status);
        end
        
        pause(1);
    end
    
catch ME
    disp(' ');
    disp('✗ Failed to start simulation');
    disp(['Error: ' ME.message]);
    disp(' ');
    disp('Troubleshooting:');
    disp('  1. Check that all S-functions compile');
    disp('  2. Verify UDP ports are available');
    disp('  3. Check MATLAB console for errors');
end

disp(' ');
disp('================================================');
disp('Simulation session ready');
disp('================================================');
