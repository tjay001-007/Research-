%% Build Complete Simulink Model for UDP-based 6DOF Aircraft Simulation
% This script creates a complete Simulink model for pitch-unstable aircraft
% simulation with UDP communication to Gazebo
%
% Run this script in MATLAB to generate: aircraft_udp_sim.slx

clear all;
close all;
clc;

%% Configuration
model_name = 'aircraft_udp_sim';
dt = 0.004;  % 250 Hz

disp('======================================================');
disp('Building Simulink Model for Aircraft UDP Simulation');
disp('======================================================');

%% Create new model
if bdIsLoaded(model_name)
    close_system(model_name, 0);
end

new_system(model_name);
open_system(model_name);

%% Configure model settings
set_param(model_name, 'Solver', 'ode4');  % Fixed-step Runge-Kutta
set_param(model_name, 'FixedStep', num2str(dt));
set_param(model_name, 'StopTime', 'inf');
set_param(model_name, 'SaveFormat', 'Array');
set_param(model_name, 'SaveOutput', 'on');
set_param(model_name, 'SaveState', 'on');

%% ========== SECTION 1: UDP RECEIVE (Controls from Gazebo) ==========

% UDP Receive block
udp_receive = add_block('simulink/User-Defined Functions/Level-2 MATLAB S-Function', ...
    [model_name '/UDP_Receive'], ...
    'MakeNameUnique', 'on');
set_param(udp_receive, 'FunctionName', 'udp_receive_sfunc');
set_param(udp_receive, 'Position', [50 50 150 100]);

% Byte to Float conversion (unpack controls)
unpack_controls = add_block('simulink/User-Defined Functions/MATLAB Function', ...
    [model_name '/Unpack_Controls'], ...
    'MakeNameUnique', 'on');
set_param(unpack_controls, 'Position', [200 50 300 100]);

% Set MATLAB Function code for unpacking
matlab_func_editor = get_param(unpack_controls, 'Object');
matlab_func_editor.Script = [...
    'function [aileron, elevator, rudder, throttle] = fcn(udp_data)' newline ...
    '% Unpack control packet: 4 floats (16 bytes) + 1 uint32 (4 bytes) = 20 bytes' newline ...
    'if length(udp_data) < 20' newline ...
    '    aileron = 0;' newline ...
    '    elevator = 0;' newline ...
    '    rudder = 0;' newline ...
    '    throttle = 0;' newline ...
    '    return;' newline ...
    'end' newline ...
    '' newline ...
    '% Convert bytes to single precision floats' newline ...
    'aileron = typecast(uint8(udp_data(1:4)), ''single'');' newline ...
    'elevator = typecast(uint8(udp_data(5:8)), ''single'');' newline ...
    'rudder = typecast(uint8(udp_data(9:12)), ''single'');' newline ...
    'throttle = typecast(uint8(udp_data(13:16)), ''single'');' newline ...
];

%% ========== SECTION 2: 6DOF AIRCRAFT DYNAMICS ==========

% 6DOF S-Function block
aircraft_dynamics = add_block('simulink/User-Defined Functions/S-Function', ...
    [model_name '/Aircraft_6DOF'], ...
    'MakeNameUnique', 'on');
set_param(aircraft_dynamics, 'FunctionName', 'aircraft_6dof_sfunc');
set_param(aircraft_dynamics, 'Position', [400 150 500 350]);

%% ========== SECTION 3: STATE PACKING ==========

% Calculate linear acceleration (for IMU simulation)
accel_calc = add_block('simulink/User-Defined Functions/MATLAB Function', ...
    [model_name '/Calculate_Accel'], ...
    'MakeNameUnique', 'on');
set_param(accel_calc, 'Position', [550 350 650 400]);

% Set acceleration calculation code
accel_editor = get_param(accel_calc, 'Object');
accel_editor.Script = [...
    'function accel = fcn(vel_body, omega_body)' newline ...
    '% Calculate body frame accelerations from velocity derivatives' newline ...
    '% For now, use simplified calculation' newline ...
    'persistent last_vel last_time' newline ...
    '' newline ...
    'dt = 0.004;  % Fixed timestep' newline ...
    '' newline ...
    'if isempty(last_vel)' newline ...
    '    last_vel = vel_body;' newline ...
    '    accel = [0; 0; 0];' newline ...
    'else' newline ...
    '    % Numerical derivative' newline ...
    '    accel = (vel_body - last_vel) / dt;' newline ...
    '    last_vel = vel_body;' newline ...
    'end' newline ...
];

% Pack state data for UDP transmission
pack_state = add_block('simulink/User-Defined Functions/MATLAB Function', ...
    [model_name '/Pack_State'], ...
    'MakeNameUnique', 'on');
set_param(pack_state, 'Position', [700 150 850 300]);

% Set packing function code
pack_editor = get_param(pack_state, 'Object');
pack_editor.Script = [...
    'function udp_data = fcn(position, quaternion, velocity, omega, accel)' newline ...
    '% Pack state packet for Gazebo' newline ...
    '% Packet: [position(3), quaternion(4), velocity(3), omega(3), accel(3)]' newline ...
    '% Total: 16 floats = 64 bytes' newline ...
    '' newline ...
    '% Convert to single precision' newline ...
    'pos_single = single(position);' newline ...
    'quat_single = single(quaternion);' newline ...
    'vel_single = single(velocity);' newline ...
    'omega_single = single(omega);' newline ...
    'accel_single = single(accel);' newline ...
    '' newline ...
    '% Concatenate all data' newline ...
    'state_vector = [pos_single; quat_single; vel_single; omega_single; accel_single];' newline ...
    '' newline ...
    '% Convert to uint8 array for UDP transmission' newline ...
    'udp_data = typecast(state_vector, ''uint8'');' newline ...
];

%% ========== SECTION 4: UDP SEND (State to Gazebo) ==========

% UDP Send block
udp_send = add_block('simulink/User-Defined Functions/Level-2 MATLAB S-Function', ...
    [model_name '/UDP_Send'], ...
    'MakeNameUnique', 'on');
set_param(udp_send, 'FunctionName', 'udp_send_sfunc');
set_param(udp_send, 'Position', [900 180 1000 230]);

%% ========== SECTION 5: SCOPES FOR MONITORING ==========

% Add scopes for debugging
scope_attitude = add_block('simulink/Sinks/Scope', ...
    [model_name '/Attitude_Scope'], ...
    'MakeNameUnique', 'on');
set_param(scope_attitude, 'Position', [550 50 600 100]);
set_param(scope_attitude, 'NumInputPorts', '3');

scope_position = add_block('simulink/Sinks/Scope', ...
    [model_name '/Position_Scope'], ...
    'MakeNameUnique', 'on');
set_param(scope_position, 'Position', [550 420 600 470]);

scope_controls = add_block('simulink/Sinks/Scope', ...
    [model_name '/Controls_Scope'], ...
    'MakeNameUnique', 'on');
set_param(scope_controls, 'Position', [350 30 400 80]);
set_param(scope_controls, 'NumInputPorts', '4');

% Display blocks
display_airspeed = add_block('simulink/Sinks/Display', ...
    [model_name '/Airspeed_Display'], ...
    'MakeNameUnique', 'on');
set_param(display_airspeed, 'Position', [550 480 600 510]);

%% ========== SECTION 6: COMPUTE AIRSPEED ==========

airspeed_calc = add_block('simulink/User-Defined Functions/MATLAB Function', ...
    [model_name '/Airspeed_Calc'], ...
    'MakeNameUnique', 'on');
set_param(airspeed_calc, 'Position', [550 260 650 290]);

airspeed_editor = get_param(airspeed_calc, 'Object');
airspeed_editor.Script = [...
    'function V = fcn(vel_body)' newline ...
    '% Calculate airspeed magnitude' newline ...
    'V = sqrt(vel_body(1)^2 + vel_body(2)^2 + vel_body(3)^2);' newline ...
];

%% ========== CONNECT ALL BLOCKS ==========

disp('Connecting blocks...');

try
    % UDP Receive -> Unpack Controls
    add_line(model_name, 'UDP_Receive/1', 'Unpack_Controls/1', 'autorouting', 'on');
    
    % Unpack Controls -> Aircraft 6DOF (4 control inputs)
    add_line(model_name, 'Unpack_Controls/1', 'Aircraft_6DOF/1', 'autorouting', 'on');
    add_line(model_name, 'Unpack_Controls/2', 'Aircraft_6DOF/2', 'autorouting', 'on');
    add_line(model_name, 'Unpack_Controls/3', 'Aircraft_6DOF/3', 'autorouting', 'on');
    add_line(model_name, 'Unpack_Controls/4', 'Aircraft_6DOF/4', 'autorouting', 'on');
    
    % Aircraft 6DOF outputs (position, quaternion, velocity, omega)
    % Position -> Pack State
    add_line(model_name, 'Aircraft_6DOF/1', 'Pack_State/1', 'autorouting', 'on');
    
    % Quaternion -> Pack State  
    add_line(model_name, 'Aircraft_6DOF/2', 'Pack_State/2', 'autorouting', 'on');
    
    % Velocity -> Pack State & Accel Calc
    add_line(model_name, 'Aircraft_6DOF/3', 'Pack_State/3', 'autorouting', 'on');
    add_line(model_name, 'Aircraft_6DOF/3', 'Calculate_Accel/1', 'autorouting', 'on');
    
    % Omega -> Pack State & Accel Calc
    add_line(model_name, 'Aircraft_6DOF/4', 'Pack_State/4', 'autorouting', 'on');
    add_line(model_name, 'Aircraft_6DOF/4', 'Calculate_Accel/2', 'autorouting', 'on');
    
    % Accel -> Pack State
    add_line(model_name, 'Calculate_Accel/1', 'Pack_State/5', 'autorouting', 'on');
    
    % Pack State -> UDP Send
    add_line(model_name, 'Pack_State/1', 'UDP_Send/1', 'autorouting', 'on');
    
    % Connect scopes
    add_line(model_name, 'Aircraft_6DOF/1', 'Position_Scope/1', 'autorouting', 'on');
    
    % Velocity to airspeed
    add_line(model_name, 'Aircraft_6DOF/3', 'Airspeed_Calc/1', 'autorouting', 'on');
    add_line(model_name, 'Airspeed_Calc/1', 'Airspeed_Display/1', 'autorouting', 'on');
    
    % Controls to scope
    add_line(model_name, 'Unpack_Controls/1', 'Controls_Scope/1', 'autorouting', 'on');
    add_line(model_name, 'Unpack_Controls/2', 'Controls_Scope/2', 'autorouting', 'on');
    add_line(model_name, 'Unpack_Controls/3', 'Controls_Scope/3', 'autorouting', 'on');
    add_line(model_name, 'Unpack_Controls/4', 'Controls_Scope/4', 'autorouting', 'on');
    
    disp('✓ All blocks connected successfully');
catch ME
    warning('Some connections failed: %s', ME.message);
    disp('You may need to connect blocks manually');
end

%% ========== SAVE MODEL ==========

% Arrange layout
Simulink.BlockDiagram.arrangeSystem(model_name);

% Save model
save_system(model_name);

disp('======================================================');
disp(['Model saved as: ' model_name '.slx']);
disp('======================================================');
disp(' ');
disp('Next steps:');
disp('1. Run: setup_aircraft_parameters.m');
disp('2. Open model: open_system(''aircraft_udp_sim'')');
disp('3. Start Gazebo with UDP plugin');
disp('4. Run simulation');
disp(' ');

%% Display model
open_system(model_name);
