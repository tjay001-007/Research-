function aircraft_6dof_sfunc(block)
% 6DOF Aircraft Dynamics S-Function
% PITCH UNSTABLE configuration for testing control systems
% 
% Inputs: aileron, elevator, rudder, throttle (each scalar)
% Outputs: position[3], quaternion[4], velocity[3], omega[3]
%
% State vector: [u v w p q r x y z phi theta psi]' (12 states)

setup(block);

function setup(block)
    % Register number of ports
    block.NumInputPorts  = 4;  % aileron, elevator, rudder, throttle
    block.NumOutputPorts = 4;  % position, quat, velocity, omega
    
    % Setup input ports (all scalars)
    for i = 1:4
        block.InputPort(i).Dimensions        = 1;
        block.InputPort(i).DatatypeID        = 0;  % double
        block.InputPort(i).Complexity        = 'Real';
        block.InputPort(i).DirectFeedthrough = false;
        block.InputPort(i).SamplingMode      = 'Sample';
    end
    
    % Setup output ports
    block.OutputPort(1).Dimensions   = 3;  % position [x, y, z]
    block.OutputPort(2).Dimensions   = 4;  % quaternion [w, x, y, z]
    block.OutputPort(3).Dimensions   = 3;  % velocity [u, v, w]
    block.OutputPort(4).Dimensions   = 3;  % omega [p, q, r]
    
    for i = 1:4
        block.OutputPort(i).DatatypeID  = 0;  % double
        block.OutputPort(i).Complexity  = 'Real';
        block.OutputPort(i).SamplingMode = 'Sample';
    end
    
    % Register sample times
    block.SampleTimes = [0 0];  % Continuous
    
    % Specify continuous state vector (12 states)
    block.NumContStates = 12;
    
    % Register methods
    block.RegBlockMethod('InitializeConditions', @InitializeConditions);
    block.RegBlockMethod('Outputs', @Outputs);
    block.RegBlockMethod('Derivatives', @Derivatives);
    block.RegBlockMethod('Start', @Start);

function Start(block)
    % Load aircraft parameters from workspace or use defaults
    if evalin('base', 'exist(''aircraft'', ''var'')')
        aircraft = evalin('base', 'aircraft');
        setappdata(0, 'AircraftParams', aircraft);
        disp('✓ Loaded aircraft parameters from workspace');
    else
        % Default parameters (pitch unstable)
        aircraft = get_default_aircraft_params();
        setappdata(0, 'AircraftParams', aircraft);
        disp('⚠ Using default aircraft parameters (pitch unstable)');
    end

function InitializeConditions(block)
    % Load initial conditions
    if evalin('base', 'exist(''initial'', ''var'')')
        initial = evalin('base', 'initial');
        block.ContStates.Data = initial.state;
        disp('✓ Loaded initial conditions from workspace');
    else
        % Default initial conditions
        % [u v w p q r x y z phi theta psi]
        block.ContStates.Data = [
            20.0;   % u - forward velocity (m/s)
            0.0;    % v - lateral velocity
            0.0;    % w - vertical velocity
            0.0;    % p - roll rate (rad/s)
            0.0;    % q - pitch rate (rad/s)
            0.0;    % r - yaw rate (rad/s)
            0.0;    % x - North position (m)
            0.0;    % y - East position (m)
            -100.0; % z - Down position (m) - negative = altitude
            0.0;    % phi - roll angle (rad)
            0.0;    % theta - pitch angle (rad)
            0.0     % psi - yaw angle (rad)
        ];
        disp('⚠ Using default initial conditions');
    end

function Outputs(block)
    % Extract states
    x_state = block.ContStates.Data;
    
    % Position (NED frame)
    position = x_state(7:9);
    block.OutputPort(1).Data = position;
    
    % Orientation as quaternion (convert from Euler angles)
    phi   = x_state(10);  % Roll
    theta = x_state(11);  % Pitch
    psi   = x_state(12);  % Yaw
    
    % Euler to quaternion (ZYX sequence)
    quat = euler_to_quaternion(phi, theta, psi);
    block.OutputPort(2).Data = quat;  % [w, x, y, z]
    
    % Velocity (body frame)
    velocity = x_state(1:3);
    block.OutputPort(3).Data = velocity;
    
    % Angular velocity (body frame)
    omega = x_state(4:6);
    block.OutputPort(4).Data = omega;

function Derivatives(block)
    % Get aircraft parameters
    aircraft = getappdata(0, 'AircraftParams');
    
    % Get control inputs
    aileron  = block.InputPort(1).Data;  % -1 to 1
    elevator = block.InputPort(2).Data;  % -1 to 1
    rudder   = block.InputPort(3).Data;  % -1 to 1
    throttle = block.InputPort(4).Data;  % 0 to 1
    
    % Current state
    x_state = block.ContStates.Data;
    u = x_state(1);     % Body x velocity
    v = x_state(2);     % Body y velocity
    w = x_state(3);     % Body z velocity
    p = x_state(4);     % Roll rate
    q = x_state(5);     % Pitch rate
    r = x_state(6);     % Yaw rate
    phi = x_state(10);   % Roll angle
    theta = x_state(11); % Pitch angle
    psi = x_state(12);   % Yaw angle
    
    % Constants
    g = 9.81;           % Gravity (m/s^2)
    rho = 1.225;        % Air density (kg/m^3)
    
    % Aerodynamic calculations
    V = sqrt(u^2 + v^2 + w^2);  % Total airspeed
    if V < 1.0
        V = 1.0;  % Avoid division by zero
    end
    
    alpha = atan2(w, u);        % Angle of attack (rad)
    beta = asin(v / V);         % Sideslip angle (rad)
    qbar = 0.5 * rho * V^2;     % Dynamic pressure
    
    % Non-dimensional rates
    p_hat = p * aircraft.b / (2*V);
    q_hat = q * aircraft.c / (2*V);
    r_hat = r * aircraft.b / (2*V);
    
    %% AERODYNAMIC FORCE COEFFICIENTS
    
    % Lift coefficient
    CL = aircraft.CL0 + aircraft.CLalpha*alpha + aircraft.CLde*elevator;
    
    % Drag coefficient  
    CD = aircraft.CD0 + aircraft.CDalpha*alpha^2;
    
    % Side force coefficient
    CY = aircraft.CYbeta*beta + aircraft.CYdr*rudder;
    
    %% AERODYNAMIC MOMENT COEFFICIENTS (PITCH UNSTABLE!)
    
    % Roll moment coefficient
    Cl = aircraft.Clbeta*beta + aircraft.Clp*p_hat + ...
         aircraft.Clr*r_hat + aircraft.Clda*aileron;
    
    % Pitch moment coefficient (UNSTABLE CONFIGURATION)
    % Cm0 > 0 and Cmalpha > 0 makes aircraft pitch unstable
    Cm = aircraft.Cm0 + aircraft.Cmalpha*alpha + ...
         aircraft.Cmq*q_hat + aircraft.Cmde*elevator;
    
    % Yaw moment coefficient
    Cn = aircraft.Cnbeta*beta + aircraft.Cnr*r_hat + ...
         aircraft.Cnda*aileron + aircraft.Cndr*rudder;
    
    %% FORCES IN WIND AXIS
    
    L_aero = qbar * aircraft.S * CL;  % Lift
    D_aero = qbar * aircraft.S * CD;  % Drag
    Y_aero = qbar * aircraft.S * CY;  % Side force
    
    %% CONVERT TO BODY AXIS FORCES
    
    % Wind to body transformation
    Fx_aero = -D_aero*cos(alpha) + L_aero*sin(alpha);
    Fy_aero = Y_aero;
    Fz_aero = -D_aero*sin(alpha) - L_aero*cos(alpha);
    
    %% THRUST
    
    T_max = 25.0;  % Maximum thrust (N)
    Fx_thrust = T_max * throttle;
    
    %% GRAVITY (transform to body frame)
    
    Fx_grav = -aircraft.mass * g * sin(theta);
    Fy_grav = aircraft.mass * g * cos(theta) * sin(phi);
    Fz_grav = aircraft.mass * g * cos(theta) * cos(phi);
    
    %% TOTAL FORCES (body frame)
    
    Fx_total = Fx_aero + Fx_thrust + Fx_grav;
    Fy_total = Fy_aero + Fy_grav;
    Fz_total = Fz_aero + Fz_grav;
    
    %% MOMENTS (body frame)
    
    L_moment = qbar * aircraft.S * aircraft.b * Cl;
    M_moment = qbar * aircraft.S * aircraft.c * Cm;
    N_moment = qbar * aircraft.S * aircraft.b * Cn;
    
    %% EQUATIONS OF MOTION (body frame)
    
    % Force equations
    udot = Fx_total/aircraft.mass + r*v - q*w;
    vdot = Fy_total/aircraft.mass + p*w - r*u;
    wdot = Fz_total/aircraft.mass + q*u - p*v;
    
    % Moment equations (Euler's equations)
    pdot = (L_moment + (aircraft.Iyy - aircraft.Izz)*q*r) / aircraft.Ixx;
    qdot = (M_moment + (aircraft.Izz - aircraft.Ixx)*p*r) / aircraft.Iyy;
    rdot = (N_moment + (aircraft.Ixx - aircraft.Iyy)*p*q) / aircraft.Izz;
    
    %% KINEMATIC EQUATIONS (Euler angles)
    
    % Avoid singularity at theta = ±90°
    if abs(cos(theta)) < 0.01
        cos_theta = sign(cos(theta)) * 0.01;
    else
        cos_theta = cos(theta);
    end
    
    phidot = p + q*sin(phi)*tan(theta) + r*cos(phi)*tan(theta);
    thetadot = q*cos(phi) - r*sin(phi);
    psidot = (q*sin(phi) + r*cos(phi)) / cos_theta;
    
    %% POSITION DERIVATIVES (NED frame)
    
    % Rotation matrix: body to NED
    c_phi = cos(phi);   s_phi = sin(phi);
    c_theta = cos(theta); s_theta = sin(theta);
    c_psi = cos(psi);   s_psi = sin(psi);
    
    % Transform body velocities to NED frame
    xdot = u*c_theta*c_psi + v*(s_phi*s_theta*c_psi - c_phi*s_psi) + ...
           w*(c_phi*s_theta*c_psi + s_phi*s_psi);
    
    ydot = u*c_theta*s_psi + v*(s_phi*s_theta*s_psi + c_phi*c_psi) + ...
           w*(c_phi*s_theta*s_psi - s_phi*c_psi);
    
    zdot = -u*s_theta + v*s_phi*c_theta + w*c_phi*c_theta;
    
    %% ASSEMBLE STATE DERIVATIVES
    
    block.Derivatives.Data = [
        udot; vdot; wdot;           % Velocity derivatives
        pdot; qdot; rdot;           % Angular velocity derivatives
        xdot; ydot; zdot;           % Position derivatives
        phidot; thetadot; psidot    % Euler angle derivatives
    ];

%% HELPER FUNCTIONS

function aircraft = get_default_aircraft_params()
    % Default aircraft parameters (PITCH UNSTABLE configuration)
    
    % Mass and inertia
    aircraft.mass = 2.0;  % kg
    aircraft.Ixx = 0.05;  % kg*m^2
    aircraft.Iyy = 0.1;   % kg*m^2
    aircraft.Izz = 0.12;  % kg*m^2
    
    % Geometry
    aircraft.S = 0.3;     % Wing area (m^2)
    aircraft.c = 0.3;     % Mean chord (m)
    aircraft.b = 1.0;     % Wing span (m)
    
    % Lift coefficients
    aircraft.CL0 = 0.3;
    aircraft.CLalpha = 4.5;  % per radian
    aircraft.CLde = 0.5;     % per radian
    
    % Drag coefficients
    aircraft.CD0 = 0.05;
    aircraft.CDalpha = 0.1;
    
    % Side force
    aircraft.CYbeta = -0.5;
    aircraft.CYdr = 0.2;
    
    % Roll moment coefficients
    aircraft.Clbeta = -0.1;
    aircraft.Clp = -0.5;
    aircraft.Clr = 0.1;
    aircraft.Clda = 0.3;
    
    % Pitch moment coefficients (UNSTABLE!)
    aircraft.Cm0 = 0.05;      % POSITIVE = nose-up moment at trim
    aircraft.Cmalpha = 0.3;   % POSITIVE = destabilizing!
    aircraft.Cmq = -3.0;      % Damping (negative is stabilizing)
    aircraft.Cmde = -0.8;     % Control power
    
    % Yaw moment coefficients
    aircraft.Cnbeta = 0.1;
    aircraft.Cnr = -0.1;
    aircraft.Cnda = -0.05;
    aircraft.Cndr = -0.1;

function quat = euler_to_quaternion(phi, theta, psi)
    % Convert Euler angles (roll, pitch, yaw) to quaternion
    % ZYX rotation sequence
    
    c_phi = cos(phi/2);
    s_phi = sin(phi/2);
    c_theta = cos(theta/2);
    s_theta = sin(theta/2);
    c_psi = cos(psi/2);
    s_psi = sin(psi/2);
    
    % Quaternion [w, x, y, z]
    quat = [
        c_phi*c_theta*c_psi + s_phi*s_theta*s_psi;  % w
        s_phi*c_theta*c_psi - c_phi*s_theta*s_psi;  % x
        c_phi*s_theta*c_psi + s_phi*c_theta*s_psi;  % y
        c_phi*c_theta*s_psi - s_phi*s_theta*c_psi   % z
    ];
    
    % Normalize
    quat = quat / norm(quat);
