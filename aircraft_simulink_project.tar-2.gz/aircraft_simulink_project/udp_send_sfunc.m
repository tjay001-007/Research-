function udp_send_sfunc(block)
% UDP Send S-Function for transmitting aircraft state to Gazebo
% Sends 64-byte packets: StatePacket structure

setup(block);

function setup(block)
    % Register number of ports
    block.NumInputPorts  = 1;
    block.NumOutputPorts = 0;
    
    % Setup input port (64 bytes = uint8 array)
    block.InputPort(1).Dimensions        = 64;
    block.InputPort(1).DatatypeID        = 3;  % uint8
    block.InputPort(1).Complexity        = 'Real';
    block.InputPort(1).DirectFeedthrough = true;
    block.InputPort(1).SamplingMode      = 'Sample';
    
    % Register sample times
    block.SampleTimes = [0.004 0];  % 250 Hz
    
    % Register methods
    block.RegBlockMethod('PostPropagationSetup', @DoPostPropSetup);
    block.RegBlockMethod('InitializeConditions', @InitializeConditions);
    block.RegBlockMethod('Start', @Start);
    block.RegBlockMethod('Outputs', @Outputs);
    block.RegBlockMethod('Terminate', @Terminate);

function DoPostPropSetup(block)
    block.NumDworks = 1;
    block.Dwork(1).Name            = 'packet_count';
    block.Dwork(1).Dimensions      = 1;
    block.Dwork(1).DatatypeID      = 0;  % double
    block.Dwork(1).Complexity      = 'Real';
    block.Dwork(1).UsedAsDiscState = true;

function InitializeConditions(block)
    block.Dwork(1).Data = 0;

function Start(block)
    % Initialize UDP port for sending
    try
        % Get parameters from base workspace
        if evalin('base', 'exist(''SIMULINK_SEND_PORT'', ''var'')')
            send_port = evalin('base', 'SIMULINK_SEND_PORT');
        else
            send_port = 15000;
        end
        
        if evalin('base', 'exist(''GAZEBO_IP'', ''var'')')
            gazebo_ip = evalin('base', 'GAZEBO_IP');
        else
            gazebo_ip = '127.0.0.1';
        end
        
        % Create UDP port object
        udp_obj = udpport("datagram");
        
        % Store in application data
        setappdata(0, 'SimulinkUDPSend', udp_obj);
        setappdata(0, 'SimulinkUDPSendPort', send_port);
        setappdata(0, 'SimulinkUDPSendIP', gazebo_ip);
        
        fprintf('UDP Send initialized: %s:%d\n', gazebo_ip, send_port);
    catch ME
        warning('Failed to initialize UDP send: %s', ME.message);
    end

function Outputs(block)
    % Get input data (64 bytes)
    state_data = uint8(block.InputPort(1).Data);
    
    % Send via UDP
    try
        udp_obj = getappdata(0, 'SimulinkUDPSend');
        send_port = getappdata(0, 'SimulinkUDPSendPort');
        gazebo_ip = getappdata(0, 'SimulinkUDPSendIP');
        
        if ~isempty(udp_obj)
            write(udp_obj, state_data, "uint8", gazebo_ip, send_port);
            
            % Increment packet counter
            block.Dwork(1).Data = block.Dwork(1).Data + 1;
            
            % Periodic status update (every 250 packets = 1 second at 250Hz)
            if mod(block.Dwork(1).Data, 250) == 0
                fprintf('UDP: Sent %d packets\n', block.Dwork(1).Data);
            end
        end
    catch ME
        % Silent fail
    end

function Terminate(block)
    % Clean up
    try
        udp_obj = getappdata(0, 'SimulinkUDPSend');
        if ~isempty(udp_obj)
            clear udp_obj;
            rmappdata(0, 'SimulinkUDPSend');
            rmappdata(0, 'SimulinkUDPSendPort');
            rmappdata(0, 'SimulinkUDPSendIP');
        end
        
        fprintf('UDP Send terminated. Total packets: %d\n', block.Dwork(1).Data);
    catch ME
        % Silent cleanup
    end
