function udp_receive_sfunc(block)
% UDP Receive S-Function for receiving control commands from Gazebo
% Receives 20-byte packets: [aileron, elevator, rudder, throttle, timestamp]

setup(block);

function setup(block)
    % Register number of ports
    block.NumInputPorts  = 0;
    block.NumOutputPorts = 1;
    
    % Setup output port (20 bytes = uint8 array)
    block.OutputPort(1).Dimensions   = 20;
    block.OutputPort(1).DatatypeID   = 3;  % uint8
    block.OutputPort(1).Complexity   = 'Real';
    block.OutputPort(1).SamplingMode = 'Sample';
    
    % Register sample times [sample_time, offset_time]
    block.SampleTimes = [0.004 0];  % 250 Hz
    
    % Register methods
    block.RegBlockMethod('PostPropagationSetup', @DoPostPropSetup);
    block.RegBlockMethod('InitializeConditions', @InitializeConditions);
    block.RegBlockMethod('Start', @Start);
    block.RegBlockMethod('Outputs', @Outputs);
    block.RegBlockMethod('Terminate', @Terminate);

function DoPostPropSetup(block)
    % Setup Dwork
    block.NumDworks = 1;
    block.Dwork(1).Name            = 'udp_obj';
    block.Dwork(1).Dimensions      = 1;
    block.Dwork(1).DatatypeID      = 0;  % double
    block.Dwork(1).Complexity      = 'Real';
    block.Dwork(1).UsedAsDiscState = true;

function InitializeConditions(block)
    block.Dwork(1).Data = 0;

function Start(block)
    % Initialize UDP port
    try
        % Get receive port from base workspace (default 15001)
        if evalin('base', 'exist(''SIMULINK_RECEIVE_PORT'', ''var'')')
            receive_port = evalin('base', 'SIMULINK_RECEIVE_PORT');
        else
            receive_port = 15001;
        end
        
        % Create UDP port object
        udp_obj = udpport("datagram", "LocalPort", receive_port, ...
                          "Timeout", 0.001);  % 1 ms timeout
        
        % Store in application data (persistent across calls)
        setappdata(0, 'SimulinkUDPReceive', udp_obj);
        
        fprintf('UDP Receive initialized on port %d\n', receive_port);
    catch ME
        warning('Failed to initialize UDP receive: %s', ME.message);
    end

function Outputs(block)
    % Default output (zeros)
    output_data = uint8(zeros(20, 1));
    
    % Try to receive data
    try
        udp_obj = getappdata(0, 'SimulinkUDPReceive');
        
        if ~isempty(udp_obj) && udp_obj.NumDatagramsAvailable > 0
            % Read one datagram
            data = read(udp_obj, 1, "uint8");
            
            if length(data.Data) >= 20
                output_data = uint8(data.Data(1:20));
            end
        end
    catch ME
        % Silent fail - return zeros
    end
    
    % Set output
    block.OutputPort(1).Data = output_data;

function Terminate(block)
    % Clean up UDP object
    try
        udp_obj = getappdata(0, 'SimulinkUDPReceive');
        if ~isempty(udp_obj)
            clear udp_obj;
            rmappdata(0, 'SimulinkUDPReceive');
        end
        disp('UDP Receive terminated');
    catch ME
        % Silent cleanup
    end
