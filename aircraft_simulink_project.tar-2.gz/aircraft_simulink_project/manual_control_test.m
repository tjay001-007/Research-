%% Manual Control Input Test
% Send control commands manually to test aircraft response
% Useful for testing specific maneuvers

clear all;
close all;
clc;

disp('========================================');
disp('Manual Control Input Test');
disp('========================================');
disp(' ');
disp('This script allows you to send manual control inputs');
disp('to the Simulink aircraft model via UDP');
disp(' ');

%% Setup

% Load parameters
if exist('aircraft_params.mat', 'file')
    load('aircraft_params.mat', 'SIMULINK_RECEIVE_PORT');
else
    SIMULINK_RECEIVE_PORT = 15001;
end

% Create UDP sender
udp_control = udpport("datagram");

disp(['Sending controls to: 127.0.0.1:' num2str(SIMULINK_RECEIVE_PORT)]);
disp(' ');

%% Control Packet Structure

function packet = create_control_packet(aileron, elevator, rudder, throttle)
    % Create 20-byte control packet
    % [aileron, elevator, rudder, throttle, timestamp]
    
    % Clamp inputs to valid ranges
    aileron = max(-1, min(1, aileron));
    elevator = max(-1, min(1, elevator));
    rudder = max(-1, min(1, rudder));
    throttle = max(0, min(1, throttle));
    
    % Pack as single precision floats
    data = single([aileron; elevator; rudder; throttle]);
    timestamp = uint32(round(now * 24 * 3600 * 1000));  % milliseconds
    
    % Convert to bytes
    float_bytes = typecast(data, 'uint8');
    time_bytes = typecast(timestamp, 'uint8');
    
    packet = [float_bytes; time_bytes];
end

%% Test Sequences

disp('Available test sequences:');
disp('  1. Trim (neutral controls)');
disp('  2. Pitch up (elevator deflection)');
disp('  3. Roll right (aileron deflection)');
disp('  4. Coordinated turn');
disp('  5. Throttle sweep');
disp('  6. Custom input');
disp('  7. Continuous manual control');
disp(' ');

choice = input('Select test (1-7): ');

switch choice
    case 1
        %% Test 1: Trim
        disp(' ');
        disp('Test 1: Sending trim (neutral) controls...');
        
        for i = 1:50  % Send for 5 seconds at 10 Hz
            packet = create_control_packet(0, 0, 0, 0.5);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            fprintf('  Sent trim: aileron=0, elevator=0, rudder=0, throttle=0.5 [%d/50]\r', i);
            pause(0.1);
        end
        disp(' ');
        disp('✓ Complete');
        
    case 2
        %% Test 2: Pitch Up
        disp(' ');
        disp('Test 2: Pitch up maneuver (elevator deflection)...');
        
        % Gradual elevator input
        for i = 1:100
            t = (i-1) * 0.1;  % Time in seconds
            
            if t < 2
                elevator = 0;  % Initial trim
            elseif t < 4
                elevator = 0.3 * (t - 2) / 2;  % Ramp up to 30%
            elseif t < 7
                elevator = 0.3;  % Hold
            else
                elevator = 0.3 * (10 - t) / 3;  % Ramp down
            end
            
            packet = create_control_packet(0, elevator, 0, 0.6);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            fprintf('  Time: %.1fs, Elevator: %+.2f, Throttle: 0.6\r', t, elevator);
            pause(0.1);
        end
        disp(' ');
        disp('✓ Complete');
        
    case 3
        %% Test 3: Roll Right
        disp(' ');
        disp('Test 3: Roll right maneuver...');
        
        for i = 1:100
            t = (i-1) * 0.1;
            
            if t < 2
                aileron = 0;
            elseif t < 4
                aileron = 0.4 * (t - 2) / 2;  % Ramp to 40%
            elseif t < 6
                aileron = 0.4;  % Hold
            else
                aileron = 0.4 * (8 - t) / 2;  % Return to neutral
            end
            
            packet = create_control_packet(aileron, 0, 0, 0.6);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            fprintf('  Time: %.1fs, Aileron: %+.2f\r', t, aileron);
            pause(0.1);
        end
        disp(' ');
        disp('✓ Complete');
        
    case 4
        %% Test 4: Coordinated Turn
        disp(' ');
        disp('Test 4: Coordinated right turn...');
        
        for i = 1:150
            t = (i-1) * 0.1;
            
            % Right turn with coordination
            if t < 3
                aileron = 0;
                rudder = 0;
            elseif t < 5
                aileron = 0.3 * (t - 3) / 2;
                rudder = 0.15 * (t - 3) / 2;
            elseif t < 10
                aileron = 0.3;
                rudder = 0.15;
            else
                aileron = 0.3 * (15 - t) / 5;
                rudder = 0.15 * (15 - t) / 5;
            end
            
            packet = create_control_packet(aileron, 0, rudder, 0.65);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            fprintf('  Time: %.1fs, Aileron: %+.2f, Rudder: %+.2f\r', t, aileron, rudder);
            pause(0.1);
        end
        disp(' ');
        disp('✓ Complete');
        
    case 5
        %% Test 5: Throttle Sweep
        disp(' ');
        disp('Test 5: Throttle sweep (0% to 100% to 0%)...');
        
        for i = 1:200
            t = (i-1) * 0.1;
            
            if t < 10
                throttle = t / 10;  % 0 to 1
            else
                throttle = (20 - t) / 10;  % 1 to 0
            end
            
            packet = create_control_packet(0, 0, 0, throttle);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            fprintf('  Time: %.1fs, Throttle: %.2f\r', t, throttle);
            pause(0.1);
        end
        disp(' ');
        disp('✓ Complete');
        
    case 6
        %% Test 6: Custom Input
        disp(' ');
        disp('Test 6: Custom control input');
        disp(' ');
        
        aileron = input('Enter aileron (-1 to 1): ');
        elevator = input('Enter elevator (-1 to 1): ');
        rudder = input('Enter rudder (-1 to 1): ');
        throttle = input('Enter throttle (0 to 1): ');
        duration = input('Duration in seconds: ');
        
        disp(' ');
        disp(['Sending for ' num2str(duration) ' seconds...']);
        
        num_packets = round(duration * 10);
        for i = 1:num_packets
            packet = create_control_packet(aileron, elevator, rudder, throttle);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            fprintf('  [%d/%d]\r', i, num_packets);
            pause(0.1);
        end
        disp(' ');
        disp('✓ Complete');
        
    case 7
        %% Test 7: Continuous Manual Control
        disp(' ');
        disp('Test 7: Continuous manual control');
        disp(' ');
        disp('Instructions:');
        disp('  Use sliders or enter values repeatedly');
        disp('  Press Ctrl+C to stop');
        disp(' ');
        
        % Create figure with sliders
        fig = figure('Name', 'Manual Control', 'Position', [100 100 400 500]);
        
        % Create sliders
        slider_aileron = uicontrol('Style', 'slider', 'Min', -1, 'Max', 1, ...
            'Value', 0, 'Position', [50 400 300 20]);
        text_aileron = uicontrol('Style', 'text', 'Position', [150 430 100 20], ...
            'String', 'Aileron: 0.00');
        
        slider_elevator = uicontrol('Style', 'slider', 'Min', -1, 'Max', 1, ...
            'Value', 0, 'Position', [50 320 300 20]);
        text_elevator = uicontrol('Style', 'text', 'Position', [150 350 100 20], ...
            'String', 'Elevator: 0.00');
        
        slider_rudder = uicontrol('Style', 'slider', 'Min', -1, 'Max', 1, ...
            'Value', 0, 'Position', [50 240 300 20]);
        text_rudder = uicontrol('Style', 'text', 'Position', [150 270 100 20], ...
            'String', 'Rudder: 0.00');
        
        slider_throttle = uicontrol('Style', 'slider', 'Min', 0, 'Max', 1, ...
            'Value', 0.5, 'Position', [50 160 300 20]);
        text_throttle = uicontrol('Style', 'text', 'Position', [150 190 100 20], ...
            'String', 'Throttle: 0.50');
        
        % Stop button
        btn_stop = uicontrol('Style', 'pushbutton', 'String', 'STOP', ...
            'Position', [150 50 100 40], 'Callback', @(src,evt) close(fig));
        
        % Send loop
        while ishandle(fig)
            aileron = get(slider_aileron, 'Value');
            elevator = get(slider_elevator, 'Value');
            rudder = get(slider_rudder, 'Value');
            throttle = get(slider_throttle, 'Value');
            
            % Update text
            set(text_aileron, 'String', sprintf('Aileron: %+.2f', aileron));
            set(text_elevator, 'String', sprintf('Elevator: %+.2f', elevator));
            set(text_rudder, 'String', sprintf('Rudder: %+.2f', rudder));
            set(text_throttle, 'String', sprintf('Throttle: %.2f', throttle));
            
            % Send packet
            packet = create_control_packet(aileron, elevator, rudder, throttle);
            write(udp_control, packet, "uint8", "127.0.0.1", SIMULINK_RECEIVE_PORT);
            
            pause(0.05);  % 20 Hz update rate
        end
        
        disp('✓ Manual control stopped');
        
    otherwise
        disp('Invalid selection');
end

%% Cleanup

clear udp_control;

disp(' ');
disp('========================================');
disp('Test complete');
disp('========================================');
